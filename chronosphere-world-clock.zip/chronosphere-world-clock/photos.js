"use strict";
const PHOTO_CATALOG = {
  "Athens": {
    "src": "assets/destinations/athens.jpg",
    "thumbnail": "assets/destinations/athens-thumb.jpg",
    "caption": "Evening Glow on Athens Street",
    "alt": "Evening Glow on Athens Street",
    "credit": "https://unsplash.com/photos/a-city-street-with-cars-parked-on-the-side-of-it-1ekxK2vGgD4",
    "position": "50% 5%"
  },
  "London": {
    "src": "assets/destinations/london.jpg",
    "thumbnail": "assets/destinations/london-thumb.jpg",
    "caption": "London Aerial Skyline",
    "alt": "London Aerial Skyline",
    "credit": "https://unsplash.com/it/foto/fotografia-aerea-dello-skyline-di-londra-durante-il-giorno-Oja2ty_9ZLM"
  },
  "Dublin": {
    "src": "assets/destinations/dublin.jpg",
    "thumbnail": "assets/destinations/dublin-thumb.jpg",
    "caption": "The Temple Bar Pub on a Cloudy Dublin Day",
    "alt": "The Temple Bar Pub on a Cloudy Dublin Day",
    "credit": "https://unsplash.com/photos/the-temple-bar-pub-in-dublin-on-a-cloudy-day-qRLpT1bos6c"
  },
  "Lisbon": {
    "src": "assets/destinations/lisbon.jpg",
    "thumbnail": "assets/destinations/lisbon-thumb.jpg",
    "caption": "Lisbon Aerial Cityscape",
    "alt": "Lisbon Aerial Cityscape",
    "credit": "https://unsplash.com/photos/aerial-view-of-city-buildings-during-daytime-HWb2iICJN1o"
  },
  "Madrid": {
    "src": "assets/destinations/madrid.jpg",
    "thumbnail": "assets/destinations/madrid-thumb.jpg",
    "caption": "Madrid’s Palacio de Cibeles",
    "alt": "Madrid’s Palacio de Cibeles",
    "credit": "https://unsplash.com/es/fotos/un-gran-edificio-blanco-con-una-torre-del-reloj-qKyO4nn7CUg"
  },
  "Paris": {
    "src": "assets/destinations/paris.jpg",
    "thumbnail": "assets/destinations/paris-thumb.jpg",
    "caption": "Eiffel Tower Over Paris Skyline",
    "alt": "Eiffel Tower Over Paris Skyline",
    "credit": "https://unsplash.com/photos/the-eiffel-tower-towering-over-the-city-of-paris-GXFSJWw1kpI",
    "position": "50% 0%"
  },
  "Brussels": {
    "src": "assets/destinations/brussels.jpg",
    "thumbnail": "assets/destinations/brussels-thumb.jpg",
    "caption": "Brussels Cityscape Aerial View",
    "alt": "Brussels Cityscape Aerial View",
    "credit": "https://unsplash.com/photos/an-aerial-view-of-a-city-with-tall-buildings-MsLhYi2Lihs"
  },
  "Amsterdam": {
    "src": "assets/destinations/amsterdam.jpg",
    "thumbnail": "assets/destinations/amsterdam-thumb.jpg",
    "caption": "Amsterdam Canal-side Architecture",
    "alt": "Amsterdam Canal-side Architecture",
    "credit": "https://unsplash.com/pt-br/fotografias/casas-de-canal-e-arvores-alinham-uma-hidrovia-em-amsterda-iQbL5Feelzs"
  },
  "Berlin": {
    "src": "assets/destinations/berlin.jpg",
    "thumbnail": "assets/destinations/berlin-thumb.jpg",
    "caption": "Berlin Skyline at Dusk",
    "alt": "Berlin Skyline at Dusk",
    "credit": "https://unsplash.com/photos/needle-tower-among-small-buildings-g8DI2ZZFt8I",
    "position": "50% 15%"
  },
  "Zurich": {
    "src": "assets/destinations/zurich.jpg",
    "thumbnail": "assets/destinations/zurich-thumb.jpg",
    "caption": "Zürich Riverside Panorama",
    "alt": "Zürich Riverside Panorama",
    "credit": "https://unsplash.com/photos/a-body-of-water-with-buildings-along-it-HVoxuKBGwgc"
  },
  "Rome": {
    "src": "assets/destinations/rome.jpg",
    "thumbnail": "assets/destinations/rome-thumb.jpg",
    "caption": "Aerial Panorama of Rome",
    "alt": "Aerial Panorama of Rome",
    "credit": "https://unsplash.com/s/photos/rome-italy"
  },
  "Vienna": {
    "src": "assets/destinations/vienna.jpg",
    "thumbnail": "assets/destinations/vienna-thumb.jpg",
    "caption": "Vienna Skyline from Stephansdom Tower",
    "alt": "Vienna Skyline from Stephansdom Tower",
    "credit": "https://unsplash.com/photos/aerial-view-of-city-buildings-during-daytime-gq1c6eXoUQg"
  },
  "Copenhagen": {
    "src": "assets/destinations/copenhagen.jpg",
    "thumbnail": "assets/destinations/copenhagen-thumb.jpg",
    "caption": "Copenhagen Canal Aerial View",
    "alt": "Copenhagen Canal Aerial View",
    "credit": "https://unsplash.com/photos/aerial-photo-of-boats-in-between-concrete-buildings-during-daytime-ePOH0oKeOjE"
  },
  "Oslo": {
    "src": "assets/destinations/oslo.jpg",
    "thumbnail": "assets/destinations/oslo-thumb.jpg",
    "caption": "Oslo Opera House by Andriy Oliynyk",
    "alt": "Oslo Opera House by Andriy Oliynyk",
    "credit": "https://unsplash.com/de/fotos/ein-gewasser-mit-gebauden-im-hintergrund-s4JItrHdDNc"
  },
  "Stockholm": {
    "src": "assets/destinations/stockholm.jpg",
    "thumbnail": "assets/destinations/stockholm-thumb.jpg",
    "caption": "Stockholm Waterfront at Dusk",
    "alt": "Stockholm Waterfront at Dusk",
    "credit": "https://unsplash.com/photos/body-of-water-near-city-buildings-during-night-time-VgU7z7SQhIs"
  },
  "Helsinki": {
    "src": "assets/destinations/helsinki.jpg",
    "thumbnail": "assets/destinations/helsinki-thumb.jpg",
    "caption": "Tram by Helsinki Cathedral",
    "alt": "Tram by Helsinki Cathedral",
    "credit": "https://unsplash.com/photos/white-and-yellow-tram-on-road-near-white-concrete-building-during-daytime-2mORf3lCSAo"
  },
  "Warsaw": {
    "src": "assets/destinations/warsaw.jpg",
    "thumbnail": "assets/destinations/warsaw-thumb.jpg",
    "caption": "Warsaw’s Iconic Clock Tower Amid Modern Skyscrapers",
    "alt": "Warsaw’s Iconic Clock Tower Amid Modern Skyscrapers",
    "credit": "https://unsplash.com/photos/a-city-street-with-tall-buildings-and-a-clock-tower-5zAilEoL5O0"
  },
  "Prague": {
    "src": "assets/destinations/prague.jpg",
    "thumbnail": "assets/destinations/prague-thumb.jpg",
    "caption": "Prague Old Town Square Aerial View",
    "alt": "Prague Old Town Square Aerial View",
    "credit": "https://unsplash.com/photos/an-aerial-view-of-a-city-with-tall-buildings-kRupbLELPb8"
  },
  "Budapest": {
    "src": "assets/destinations/budapest.jpg",
    "thumbnail": "assets/destinations/budapest-thumb.jpg",
    "caption": "Budapest’s Nighttime Landmarks",
    "alt": "Budapest’s Nighttime Landmarks",
    "credit": "https://unsplash.com/de/fotos/das-budapester-parlament-und-die-kettenbrucke-leuchten-nachts-6QKZHOZeryk"
  },
  "Bucharest": {
    "src": "assets/destinations/bucharest.jpg",
    "thumbnail": "assets/destinations/bucharest-thumb.jpg",
    "caption": "Umbrella Canopy in Bucharest",
    "alt": "Umbrella Canopy in Bucharest",
    "credit": "https://unsplash.com/photos/a-bunch-of-umbrellas-that-are-outside-of-a-building-x3xMpP6HYRI"
  },
  "Sofia": {
    "src": "assets/destinations/sofia.jpg",
    "thumbnail": "assets/destinations/sofia-thumb.jpg",
    "caption": "Sofia Cityscape from Above",
    "alt": "Sofia Cityscape from Above",
    "credit": "https://unsplash.com/photos/birds-eye-view-of-cityscape-near-road-during-daytime-m4DOppSy9cA"
  },
  "Belgrade": {
    "src": "assets/destinations/belgrade.jpg",
    "thumbnail": "assets/destinations/belgrade-thumb.jpg",
    "caption": "Belgrade Street Stroll",
    "alt": "Belgrade Street Stroll",
    "credit": "https://unsplash.com/photos/a-group-of-people-walking-down-a-street-next-to-tall-buildings-sLO6KQKL2ZA"
  },
  "Kyiv": {
    "src": "assets/destinations/kyiv.jpg",
    "thumbnail": "assets/destinations/kyiv-thumb.jpg",
    "caption": "Kyiv Night Aerial Panorama",
    "alt": "Kyiv Night Aerial Panorama",
    "credit": "https://unsplash.com/photos/an-aerial-view-of-a-city-at-night-z83fbJzzplM"
  },
  "Reykjavik": {
    "src": "assets/destinations/reykjavik.jpg",
    "thumbnail": "assets/destinations/reykjavik-thumb.jpg",
    "caption": "Reykjavík Aerial Cityscape",
    "alt": "Reykjavík Aerial Cityscape",
    "credit": "https://unsplash.com/photos/aerial-view-of-city-buildings-during-daytime-oLZzZhjMIBw"
  },
  "Istanbul": {
    "src": "assets/destinations/istanbul.jpg",
    "thumbnail": "assets/destinations/istanbul-thumb.jpg",
    "caption": "Istanbul at Dusk",
    "alt": "Istanbul at Dusk",
    "credit": "https://unsplash.com/s/photos/istanbul-bosphorus-bridge"
  },
  "Dubai": {
    "src": "assets/destinations/dubai.jpg",
    "thumbnail": "assets/destinations/dubai-thumb.jpg",
    "caption": "Dubai Sunset Skyline",
    "alt": "Dubai Sunset Skyline",
    "credit": "https://unsplash.com/fr/photos/une-grande-ville-avec-de-grands-immeubles-NGLDzlsc7qM"
  },
  "New Delhi": {
    "src": "assets/destinations/new-delhi.jpg",
    "thumbnail": "assets/destinations/new-delhi-thumb.jpg",
    "caption": "Morning Traffic at India Gate",
    "alt": "Morning Traffic at India Gate",
    "credit": "https://unsplash.com/s/photos/delhi-city"
  },
  "Bangkok": {
    "src": "assets/destinations/bangkok.jpg",
    "thumbnail": "assets/destinations/bangkok-thumb.jpg",
    "caption": "Bangkok Night Skyline",
    "alt": "Bangkok Night Skyline",
    "credit": "https://unsplash.com/pt-br/s/fotografias/bangkok-%2Cthailand"
  },
  "Singapore": {
    "src": "assets/destinations/singapore.jpg",
    "thumbnail": "assets/destinations/singapore-thumb.jpg",
    "caption": "Marina Bay Sands at Dusk",
    "alt": "Marina Bay Sands at Dusk",
    "credit": "https://unsplash.com/photos/marina-bay-sands-tFOrQ1v5FMc"
  },
  "Beijing": {
    "src": "assets/destinations/beijing.jpg",
    "thumbnail": "assets/destinations/beijing-thumb.jpg",
    "caption": "Beijing Dusk Skyline",
    "alt": "Beijing Dusk Skyline",
    "credit": "https://unsplash.com/s/photos/beijing-china"
  },
  "Hong Kong": {
    "src": "assets/destinations/hong-kong.jpg",
    "thumbnail": "assets/destinations/hong-kong-thumb.jpg",
    "caption": "Hong Kong Night Skyline",
    "alt": "Hong Kong Night Skyline",
    "credit": "https://unsplash.com/photos/lighted-city-skyline-across-bay-fxL_25o92ZA"
  },
  "Tokyo": {
    "src": "assets/destinations/tokyo.jpg",
    "thumbnail": "assets/destinations/tokyo-thumb.jpg",
    "caption": "Tokyo Tower Amidst Urban Sprawl",
    "alt": "Tokyo Tower Amidst Urban Sprawl",
    "credit": "https://unsplash.com/photos/aerial-view-of-city-buildings-during-daytime-cMTWrbqcESs",
    "position": "50% 25%"
  },
  "Seoul": {
    "src": "assets/destinations/seoul.jpg",
    "thumbnail": "assets/destinations/seoul-thumb.jpg",
    "caption": "Seoul Skyline Contrast",
    "alt": "Seoul Skyline Contrast",
    "credit": "https://unsplash.com/photos/a-view-of-a-city-with-tall-buildings-tu1GGuJLQOs"
  },
  "Jakarta": {
    "src": "assets/destinations/jakarta.jpg",
    "thumbnail": "assets/destinations/jakarta-thumb.jpg",
    "caption": "Jakarta Skyline Under Blue Sky",
    "alt": "Jakarta Skyline Under Blue Sky",
    "credit": "https://unsplash.com/photos/city-skyline-under-blue-and-white-cloudy-sky-during-daytime-GdMehFdii0s"
  },
  "Manila": {
    "src": "assets/destinations/manila.jpg",
    "thumbnail": "assets/destinations/manila-thumb.jpg",
    "caption": "Manila Night Skyline",
    "alt": "Manila Night Skyline",
    "credit": "https://unsplash.com/photos/a-city-skyline-at-night-FqgIZnZH3ww"
  },
  "Hanoi": {
    "src": "assets/destinations/hanoi.jpg",
    "thumbnail": "assets/destinations/hanoi-thumb.jpg",
    "caption": "Hanoi Night Skyline",
    "alt": "Hanoi Night Skyline",
    "credit": "https://unsplash.com/photos/lighted-cityscape-at-night-Cj9YgIWSpTs"
  },
  "Cairo": {
    "src": "assets/destinations/cairo.jpg",
    "thumbnail": "assets/destinations/cairo-thumb.jpg",
    "caption": "Mosque-Madrasa of Sultan Hassan in Cairo",
    "alt": "Mosque-Madrasa of Sultan Hassan in Cairo",
    "credit": "https://unsplash.com/photos/a-view-of-a-city-with-a-lot-of-tall-buildings-hxvl0wdAdso"
  },
  "Casablanca": {
    "src": "assets/destinations/casablanca.jpg",
    "thumbnail": "assets/destinations/casablanca-thumb.jpg",
    "caption": "Hassan II Mosque on the Atlantic Coast",
    "alt": "Hassan II Mosque on the Atlantic Coast",
    "credit": "https://unsplash.com/fr/photos/un-grand-batiment-blanc-avec-un-toit-vert-qL3_NSPo9o8"
  },
  "Addis Ababa": {
    "src": "assets/destinations/addis-ababa.jpg",
    "thumbnail": "assets/destinations/addis-ababa-thumb.jpg",
    "caption": "Busy Addis Ababa Street",
    "alt": "Busy Addis Ababa Street",
    "credit": "https://unsplash.com/photos/busy-city-street-with-modern-buildings-and-traffic-u5UktTgW-Yw"
  },
  "New York": {
    "src": "assets/destinations/new-york.jpg",
    "thumbnail": "assets/destinations/new-york-thumb.jpg",
    "caption": "New York City Skyline with Empire State Building",
    "alt": "New York City Skyline with Empire State Building",
    "credit": "https://unsplash.com/photos/expansive-new-york-city-skyline-with-empire-state-building-InYinJ1zJk0"
  },
  "Los Angeles": {
    "src": "assets/destinations/los-angeles.jpg",
    "thumbnail": "assets/destinations/los-angeles-thumb.jpg",
    "caption": "Los Angeles Highway Interchange",
    "alt": "Los Angeles Highway Interchange",
    "credit": "https://unsplash.com/photos/an-aerial-view-of-a-highway-intersection-in-a-city-vjWoY7jIevs"
  },
  "Toronto": {
    "src": "assets/destinations/toronto.jpg",
    "thumbnail": "assets/destinations/toronto-thumb.jpg",
    "caption": "Toronto Skyline at Golden Hour",
    "alt": "Toronto Skyline at Golden Hour",
    "credit": "https://unsplash.com/s/photos/toronto-skyline"
  },
  "Vancouver": {
    "src": "assets/destinations/vancouver.jpg",
    "thumbnail": "assets/destinations/vancouver-thumb.jpg",
    "caption": "Vancouver Skyline Over False Creek",
    "alt": "Vancouver Skyline Over False Creek",
    "credit": "https://unsplash.com/es/fotos/una-vista-aerea-de-una-ciudad-y-un-puerto-Wc45W-dQFlA"
  },
  "Mexico City": {
    "src": "assets/destinations/mexico-city.jpg",
    "thumbnail": "assets/destinations/mexico-city-thumb.jpg",
    "caption": "Mexico City’s Angel of Independence Avenue",
    "alt": "Mexico City’s Angel of Independence Avenue",
    "credit": "https://unsplash.com/photos/a-city-street-with-a-monument-in-the-background-KJgoOAxq9ns"
  },
  "Havana": {
    "src": "assets/destinations/havana.jpg",
    "thumbnail": "assets/destinations/havana-thumb.jpg",
    "caption": "Vintage Cars by El Capitolio",
    "alt": "Vintage Cars by El Capitolio",
    "credit": "https://unsplash.com/photos/different-vehicles-on-road-viewing-white-dome-historic-building-during-daytime-L6mKnwc6y48"
  },
  "São Paulo": {
    "src": "assets/destinations/s-o-paulo.jpg",
    "thumbnail": "assets/destinations/s-o-paulo-thumb.jpg",
    "caption": "São Paulo Sunset Avenue",
    "alt": "São Paulo Sunset Avenue",
    "credit": "https://unsplash.com/s/photos/sao-paulo"
  },
  "Buenos Aires": {
    "src": "assets/destinations/buenos-aires.jpg",
    "thumbnail": "assets/destinations/buenos-aires-thumb.jpg",
    "caption": "Buenos Aires Avenida Corrientes",
    "alt": "Buenos Aires Avenida Corrientes",
    "credit": "https://unsplash.com/photos/a-city-street-filled-with-lots-of-tall-buildings-qKv9qePY5zg"
  },
  "Santiago": {
    "src": "assets/destinations/santiago.jpg",
    "thumbnail": "assets/destinations/santiago-thumb.jpg",
    "caption": "Santiago Panorama from Cerro San Cristóbal",
    "alt": "Santiago Panorama from Cerro San Cristóbal",
    "credit": "https://unsplash.com/es/fotos/una-vista-panoramica-de-una-ciudad-con-montanas-al-fondo-12-2SSF7OrE"
  },
  "Bogotá": {
    "src": "assets/destinations/bogot.jpg",
    "thumbnail": "assets/destinations/bogot-thumb.jpg",
    "caption": "Bogotá Cityscape Aerial View",
    "alt": "Bogotá Cityscape Aerial View",
    "credit": "https://unsplash.com/s/photos/bogota-colombia"
  },
  "Lima": {
    "src": "assets/destinations/lima.jpg",
    "thumbnail": "assets/destinations/lima-thumb.jpg",
    "caption": "Lima Coastal Skyline",
    "alt": "Lima Coastal Skyline",
    "credit": "https://unsplash.com/es/s/fotos/lima-peru"
  },
  "Sydney": {
    "src": "assets/destinations/sydney.jpg",
    "thumbnail": "assets/destinations/sydney-thumb.jpg",
    "caption": "Sydney Harbour at Dusk",
    "alt": "Sydney Harbour at Dusk",
    "credit": "https://unsplash.com/fr/photos/opera-de-sydney-australie-MvEuQRRRUIo"
  },
  "Perth": {
    "src": "assets/destinations/perth.jpg",
    "thumbnail": "assets/destinations/perth-thumb.jpg",
    "caption": "Perth Skyline from Kings Park",
    "alt": "Perth Skyline from Kings Park",
    "credit": "https://unsplash.com/photos/a-view-of-a-city-and-the-ocean-from-a-hill-gl7nkS_h4lo"
  },
  "Auckland": {
    "src": "assets/destinations/auckland.jpg",
    "thumbnail": "assets/destinations/auckland-thumb.jpg",
    "caption": "Auckland Harbor Skyline",
    "alt": "Auckland Harbor Skyline",
    "credit": "https://unsplash.com/photos/city-skyline-across-body-of-water-during-daytime-CSCoasDuU2U"
  },
  "Zagreb": {
    "src": "assets/destinations/zagreb.jpg",
    "thumbnail": "assets/destinations/zagreb-thumb.jpg",
    "caption": "Zagreb Street Scene",
    "alt": "Zagreb Street Scene",
    "credit": "https://unsplash.com/es/fotos/una-mujer-parada-en-medio-de-una-calle-mxyqZSyAbcE"
  },
  "Riyadh": {
    "src": "assets/destinations/riyadh.jpg",
    "thumbnail": "assets/destinations/riyadh-thumb.jpg",
    "caption": "Hisma Desert, Saudi Arabia",
    "alt": "Hisma Desert, Saudi Arabia",
    "credit": "https://unsplash.com/photos/a-person-standing-in-front-of-a-rock-formation-_TFgiFZyH6M"
  },
  "Islamabad": {
    "src": "assets/destinations/islamabad.jpg",
    "thumbnail": "assets/destinations/islamabad-thumb.jpg",
    "caption": "Faisal Mosque Reflection",
    "alt": "Faisal Mosque Reflection",
    "credit": "https://unsplash.com/s/photos/faisal-mosque"
  },
  "Dhaka": {
    "src": "assets/destinations/dhaka.jpg",
    "thumbnail": "assets/destinations/dhaka-thumb.jpg",
    "caption": "Sylhet, Bangladesh",
    "alt": "Sylhet, Bangladesh",
    "credit": "https://unsplash.com/s/photos/sylhet%2C-bangladesh"
  },
  "Suva": {
    "src": "assets/destinations/suva.jpg",
    "thumbnail": "assets/destinations/suva-thumb.jpg",
    "caption": "Island coastline, Fiji",
    "alt": "Island coastline, Fiji",
    "credit": "https://unsplash.com/photos/green-palm-trees-beside-body-of-water-during-daytime-8UC2ghvfoCI"
  },
  "Johannesburg": {
    "src": "assets/destinations/johannesburg.jpg",
    "thumbnail": "assets/destinations/johannesburg-thumb.jpg",
    "caption": "Safari landscape, South Africa",
    "alt": "Safari landscape, South Africa",
    "credit": "https://unsplash.com/photos/a-couple-of-elephants-walking-in-a-field-snTfL3nnj8g"
  },
  "Lagos": {
    "src": "assets/destinations/lagos.jpg",
    "thumbnail": "assets/destinations/lagos-thumb.jpg",
    "caption": "Lagos Street Market Traffic",
    "alt": "Lagos Street Market Traffic",
    "credit": "https://unsplash.com/fr/photos/une-rue-de-la-ville-remplie-de-beaucoup-de-circulation-vvQW-3yfuos"
  },
  "Nairobi": {
    "src": "assets/destinations/nairobi.jpg",
    "thumbnail": "assets/destinations/nairobi-thumb.jpg",
    "caption": "Savanna landscape, Kenya",
    "alt": "Savanna landscape, Kenya",
    "credit": "https://unsplash.com/photos/tree-between-green-land-during-golden-hour-T-LfvX-7IVg"
  }
};
