"use strict";

const CACHE_NAME = "chronosphere-v4";
importScripts("./photos.js");
const APP_ASSETS = [
  "./photos.js",
  "./PHOTO-CREDITS.html",
  "./assets/flags/ae.svg",
  "./assets/flags/ar.svg",
  "./assets/flags/at.svg",
  "./assets/flags/au.svg",
  "./assets/flags/bd.svg",
  "./assets/flags/be.svg",
  "./assets/flags/bg.svg",
  "./assets/flags/br.svg",
  "./assets/flags/ca.svg",
  "./assets/flags/ch.svg",
  "./assets/flags/cl.svg",
  "./assets/flags/cn.svg",
  "./assets/flags/co.svg",
  "./assets/flags/cu.svg",
  "./assets/flags/cz.svg",
  "./assets/flags/de.svg",
  "./assets/flags/dk.svg",
  "./assets/flags/eg.svg",
  "./assets/flags/es.svg",
  "./assets/flags/et.svg",
  "./assets/flags/fi.svg",
  "./assets/flags/fj.svg",
  "./assets/flags/fr.svg",
  "./assets/flags/gb.svg",
  "./assets/flags/gr.svg",
  "./assets/flags/hk.svg",
  "./assets/flags/hr.svg",
  "./assets/flags/hu.svg",
  "./assets/flags/id.svg",
  "./assets/flags/ie.svg",
  "./assets/flags/in.svg",
  "./assets/flags/is.svg",
  "./assets/flags/it.svg",
  "./assets/flags/jp.svg",
  "./assets/flags/ke.svg",
  "./assets/flags/kr.svg",
  "./assets/flags/ma.svg",
  "./assets/flags/mx.svg",
  "./assets/flags/ng.svg",
  "./assets/flags/nl.svg",
  "./assets/flags/no.svg",
  "./assets/flags/nz.svg",
  "./assets/flags/pe.svg",
  "./assets/flags/ph.svg",
  "./assets/flags/pk.svg",
  "./assets/flags/pl.svg",
  "./assets/flags/pt.svg",
  "./assets/flags/ro.svg",
  "./assets/flags/rs.svg",
  "./assets/flags/sa.svg",
  "./assets/flags/se.svg",
  "./assets/flags/sg.svg",
  "./assets/flags/th.svg",
  "./assets/flags/tr.svg",
  "./assets/flags/ua.svg",
  "./assets/flags/us.svg",
  "./assets/flags/vn.svg",
  "./assets/flags/za.svg",
  ...Object.values(PHOTO_CATALOG).flatMap(photo => ["./" + photo.src, "./" + photo.thumbnail]),
  "./",
  "./index.html",
  "./styles.css",
  "./data.js",
  "./app.js",
  "./manifest.webmanifest",
  "./icons/icon-192.png",
  "./icons/icon-512.png"
];

self.addEventListener("install", event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => cache.addAll(APP_ASSETS))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", event => {
  event.waitUntil(
    caches.keys()
      .then(keys => Promise.all(
        keys.filter(key => key.startsWith("chronosphere-") && key !== CACHE_NAME).map(key => caches.delete(key))
      ))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", event => {
  if (event.request.method !== "GET") return;

  event.respondWith(
    caches.match(event.request).then(cachedResponse => {
      if (cachedResponse) return cachedResponse;

      return fetch(event.request)
        .then(networkResponse => {
          if (!networkResponse || networkResponse.status !== 200) return networkResponse;
          const responseCopy = networkResponse.clone();
          caches.open(CACHE_NAME).then(cache => cache.put(event.request, responseCopy));
          return networkResponse;
        })
        .catch(() => {
          if (event.request.mode === "navigate") return caches.match("./index.html");
          return new Response("Offline", { status: 503, statusText: "Offline" });
        });
    })
  );
});
