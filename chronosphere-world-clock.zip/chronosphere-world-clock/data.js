const WORLD_LOCATIONS = [
  {
    "country": "Greece",
    "city": "Athens",
    "timezone": "Europe/Athens",
    "continent": "Europe",
    "code": "GR"
  },
  {
    "country": "United Kingdom",
    "city": "London",
    "timezone": "Europe/London",
    "continent": "Europe",
    "code": "GB"
  },
  {
    "country": "Ireland",
    "city": "Dublin",
    "timezone": "Europe/Dublin",
    "continent": "Europe",
    "code": "IE"
  },
  {
    "country": "Portugal",
    "city": "Lisbon",
    "timezone": "Europe/Lisbon",
    "continent": "Europe",
    "code": "PT"
  },
  {
    "country": "Spain",
    "city": "Madrid",
    "timezone": "Europe/Madrid",
    "continent": "Europe",
    "code": "ES"
  },
  {
    "country": "France",
    "city": "Paris",
    "timezone": "Europe/Paris",
    "continent": "Europe",
    "code": "FR"
  },
  {
    "country": "Belgium",
    "city": "Brussels",
    "timezone": "Europe/Brussels",
    "continent": "Europe",
    "code": "BE"
  },
  {
    "country": "Netherlands",
    "city": "Amsterdam",
    "timezone": "Europe/Amsterdam",
    "continent": "Europe",
    "code": "NL"
  },
  {
    "country": "Germany",
    "city": "Berlin",
    "timezone": "Europe/Berlin",
    "continent": "Europe",
    "code": "DE"
  },
  {
    "country": "Switzerland",
    "city": "Zurich",
    "timezone": "Europe/Zurich",
    "continent": "Europe",
    "code": "CH"
  },
  {
    "country": "Italy",
    "city": "Rome",
    "timezone": "Europe/Rome",
    "continent": "Europe",
    "code": "IT"
  },
  {
    "country": "Austria",
    "city": "Vienna",
    "timezone": "Europe/Vienna",
    "continent": "Europe",
    "code": "AT"
  },
  {
    "country": "Denmark",
    "city": "Copenhagen",
    "timezone": "Europe/Copenhagen",
    "continent": "Europe",
    "code": "DK"
  },
  {
    "country": "Norway",
    "city": "Oslo",
    "timezone": "Europe/Oslo",
    "continent": "Europe",
    "code": "NO"
  },
  {
    "country": "Sweden",
    "city": "Stockholm",
    "timezone": "Europe/Stockholm",
    "continent": "Europe",
    "code": "SE"
  },
  {
    "country": "Finland",
    "city": "Helsinki",
    "timezone": "Europe/Helsinki",
    "continent": "Europe",
    "code": "FI"
  },
  {
    "country": "Poland",
    "city": "Warsaw",
    "timezone": "Europe/Warsaw",
    "continent": "Europe",
    "code": "PL"
  },
  {
    "country": "Czechia",
    "city": "Prague",
    "timezone": "Europe/Prague",
    "continent": "Europe",
    "code": "CZ"
  },
  {
    "country": "Hungary",
    "city": "Budapest",
    "timezone": "Europe/Budapest",
    "continent": "Europe",
    "code": "HU"
  },
  {
    "country": "Romania",
    "city": "Bucharest",
    "timezone": "Europe/Bucharest",
    "continent": "Europe",
    "code": "RO"
  },
  {
    "country": "Bulgaria",
    "city": "Sofia",
    "timezone": "Europe/Sofia",
    "continent": "Europe",
    "code": "BG"
  },
  {
    "country": "Croatia",
    "city": "Zagreb",
    "timezone": "Europe/Zagreb",
    "continent": "Europe",
    "code": "HR"
  },
  {
    "country": "Serbia",
    "city": "Belgrade",
    "timezone": "Europe/Belgrade",
    "continent": "Europe",
    "code": "RS"
  },
  {
    "country": "Ukraine",
    "city": "Kyiv",
    "timezone": "Europe/Kyiv",
    "continent": "Europe",
    "code": "UA"
  },
  {
    "country": "Iceland",
    "city": "Reykjavik",
    "timezone": "Atlantic/Reykjavik",
    "continent": "Europe",
    "code": "IS"
  },
  {
    "country": "Turkey",
    "city": "Istanbul",
    "timezone": "Europe/Istanbul",
    "continent": "Asia",
    "code": "TR"
  },
  {
    "country": "United Arab Emirates",
    "city": "Dubai",
    "timezone": "Asia/Dubai",
    "continent": "Asia",
    "code": "AE"
  },
  {
    "country": "Saudi Arabia",
    "city": "Riyadh",
    "timezone": "Asia/Riyadh",
    "continent": "Asia",
    "code": "SA"
  },
  {
    "country": "India",
    "city": "New Delhi",
    "timezone": "Asia/Kolkata",
    "continent": "Asia",
    "code": "IN"
  },
  {
    "country": "Pakistan",
    "city": "Islamabad",
    "timezone": "Asia/Karachi",
    "continent": "Asia",
    "code": "PK"
  },
  {
    "country": "Bangladesh",
    "city": "Dhaka",
    "timezone": "Asia/Dhaka",
    "continent": "Asia",
    "code": "BD"
  },
  {
    "country": "Thailand",
    "city": "Bangkok",
    "timezone": "Asia/Bangkok",
    "continent": "Asia",
    "code": "TH"
  },
  {
    "country": "Singapore",
    "city": "Singapore",
    "timezone": "Asia/Singapore",
    "continent": "Asia",
    "code": "SG"
  },
  {
    "country": "China",
    "city": "Beijing",
    "timezone": "Asia/Shanghai",
    "continent": "Asia",
    "code": "CN"
  },
  {
    "country": "Hong Kong",
    "city": "Hong Kong",
    "timezone": "Asia/Hong_Kong",
    "continent": "Asia",
    "code": "HK"
  },
  {
    "country": "Japan",
    "city": "Tokyo",
    "timezone": "Asia/Tokyo",
    "continent": "Asia",
    "code": "JP"
  },
  {
    "country": "South Korea",
    "city": "Seoul",
    "timezone": "Asia/Seoul",
    "continent": "Asia",
    "code": "KR"
  },
  {
    "country": "Indonesia",
    "city": "Jakarta",
    "timezone": "Asia/Jakarta",
    "continent": "Asia",
    "code": "ID"
  },
  {
    "country": "Philippines",
    "city": "Manila",
    "timezone": "Asia/Manila",
    "continent": "Asia",
    "code": "PH"
  },
  {
    "country": "Vietnam",
    "city": "Hanoi",
    "timezone": "Asia/Ho_Chi_Minh",
    "continent": "Asia",
    "code": "VN"
  },
  {
    "country": "Egypt",
    "city": "Cairo",
    "timezone": "Africa/Cairo",
    "continent": "Africa",
    "code": "EG"
  },
  {
    "country": "South Africa",
    "city": "Johannesburg",
    "timezone": "Africa/Johannesburg",
    "continent": "Africa",
    "code": "ZA"
  },
  {
    "country": "Morocco",
    "city": "Casablanca",
    "timezone": "Africa/Casablanca",
    "continent": "Africa",
    "code": "MA"
  },
  {
    "country": "Nigeria",
    "city": "Lagos",
    "timezone": "Africa/Lagos",
    "continent": "Africa",
    "code": "NG"
  },
  {
    "country": "Kenya",
    "city": "Nairobi",
    "timezone": "Africa/Nairobi",
    "continent": "Africa",
    "code": "KE"
  },
  {
    "country": "Ethiopia",
    "city": "Addis Ababa",
    "timezone": "Africa/Addis_Ababa",
    "continent": "Africa",
    "code": "ET"
  },
  {
    "country": "United States",
    "city": "New York",
    "timezone": "America/New_York",
    "continent": "North America",
    "code": "US"
  },
  {
    "country": "United States",
    "city": "Los Angeles",
    "timezone": "America/Los_Angeles",
    "continent": "North America",
    "code": "US"
  },
  {
    "country": "Canada",
    "city": "Toronto",
    "timezone": "America/Toronto",
    "continent": "North America",
    "code": "CA"
  },
  {
    "country": "Canada",
    "city": "Vancouver",
    "timezone": "America/Vancouver",
    "continent": "North America",
    "code": "CA"
  },
  {
    "country": "Mexico",
    "city": "Mexico City",
    "timezone": "America/Mexico_City",
    "continent": "North America",
    "code": "MX"
  },
  {
    "country": "Cuba",
    "city": "Havana",
    "timezone": "America/Havana",
    "continent": "North America",
    "code": "CU"
  },
  {
    "country": "Brazil",
    "city": "São Paulo",
    "timezone": "America/Sao_Paulo",
    "continent": "South America",
    "code": "BR"
  },
  {
    "country": "Argentina",
    "city": "Buenos Aires",
    "timezone": "America/Argentina/Buenos_Aires",
    "continent": "South America",
    "code": "AR"
  },
  {
    "country": "Chile",
    "city": "Santiago",
    "timezone": "America/Santiago",
    "continent": "South America",
    "code": "CL"
  },
  {
    "country": "Colombia",
    "city": "Bogotá",
    "timezone": "America/Bogota",
    "continent": "South America",
    "code": "CO"
  },
  {
    "country": "Peru",
    "city": "Lima",
    "timezone": "America/Lima",
    "continent": "South America",
    "code": "PE"
  },
  {
    "country": "Australia",
    "city": "Sydney",
    "timezone": "Australia/Sydney",
    "continent": "Oceania",
    "code": "AU"
  },
  {
    "country": "Australia",
    "city": "Perth",
    "timezone": "Australia/Perth",
    "continent": "Oceania",
    "code": "AU"
  },
  {
    "country": "New Zealand",
    "city": "Auckland",
    "timezone": "Pacific/Auckland",
    "continent": "Oceania",
    "code": "NZ"
  },
  {
    "country": "Fiji",
    "city": "Suva",
    "timezone": "Pacific/Fiji",
    "continent": "Oceania",
    "code": "FJ"
  }
];
