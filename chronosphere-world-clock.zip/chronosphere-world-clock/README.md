# ChronoSphere World Clock — Version 4.0

A visual, offline-ready world clock with 61 destinations across 58 countries.

## Open the app

1. Extract `chronosphere-world-clock.zip`.
2. Open `chronosphere-world-clock/index.html` in your browser.
3. Choose **Try the demo**, or sign in with username `joker` and password `joker1234`.

No build step, API key, or internet connection is required. Photographs, flags,
styles, and scripts are included in the download.

## A place for every time zone

- Choose a city in **Where would you like to be?** to change the large photograph,
  country label, date, live digital and analogue clocks, UTC offset, and time
  difference from your device's time zone.
- Use the previous/next buttons or the desktop quick destinations to explore.
- Select **Explore place** on a clock card to open that destination.
- Save a destination using the star button; use **Saved** to see favourites.
- Select **Compare this place** to open the two-city comparison. Both selectors
  update their photos, and **Swap cities** reverses the comparison.
- Search by city, country, or IANA time zone. Press `/` to focus search.
- Filter by continent, switch between 12-hour and 24-hour formats, or change
  the sort order. The first six cards appear immediately; **Show more places**
  loads another twelve.
- Your selected destination, favourites, colour theme, and time format are saved
  on this device when browser storage is available.

## Design and accessibility

The dashboard includes a photographic destination feature, a live clock face,
a 24-hour strip with 09:00–17:00 highlighted for reference, photo clock cards,
light and dark themes, and bottom navigation on phones. The strip is a simple
hour-of-day guide, not a business-availability or sunrise/sunset forecast.

Keyboard controls, labelled buttons, selected states, visible focus indicators,
selection announcements, and reduced-motion preferences are supported. Clock
updates pause while the app is hidden to reduce unnecessary work.

## Photos and flags

All 61 destination photographs are bundled with smaller card thumbnails.
Some images show a wider country scene instead of the selected city; the photo
caption identifies the pictured place. Images are representative photographs,
not live views of weather or current daylight.

See `PHOTO-CREDITS.html` for the original Unsplash sources and licence link.
The included SVG flags come from flag-icons by Panayiotis Lipiridis; its MIT
licence is in `assets/flags/LICENSE.txt`.

`PREVIEW.png` shows the redesigned desktop dashboard.

## Installable offline app

For service-worker caching and installation, serve the folder over localhost
or HTTPS. From the application folder, run:

```bash
python -m http.server 8080
```

Open `http://localhost:8080`, wait for the initial offline cache to finish, and
use **Install app** when supported by your browser. The first cached visit
includes the bundled photo collection (about 19 MB). Normal folder-based use
works offline immediately after extracting the ZIP.

## Validation

Browser checks passed for:

- Loading the photograph for every one of the 61 time-zone selections
- Destination selection, saved places, and persistence across reloads
- Comparison photographs, selector changes, and swapping cities
- Search, empty results, pagination, 12-hour format, and colour themes
- No horizontal page overflow at 320, 360, 390, 600, 768, 1024, and 1440 pixels
- Service-worker offline reload and an offline destination change
- Direct `file://` opening with a working destination image
- No browser JavaScript errors during those checks

Desktop, dark-theme, login, and phone screenshots were visually reviewed.
JavaScript syntax and bundled asset integrity were checked as well.

## Demo login

This is a client-side demo login. Credentials are visible in `app.js`; it does
not provide production authentication or protect private data.
