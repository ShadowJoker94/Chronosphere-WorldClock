"use strict";

const LOGIN_USERNAME = "joker";
const LOGIN_PASSWORD = "joker1234";
const HOME_TIMEZONE = "Europe/Athens";
const AUTH_KEY = "chronosphere-authenticated";
const FAVOURITES_KEY = "chronosphere-favourites";
const THEME_KEY = "chronosphere-theme";

const elements = {
  loginView: document.getElementById("login-view"),
  dashboardView: document.getElementById("dashboard-view"),
  loginPanel: document.querySelector(".login-panel"),
  loginForm: document.getElementById("login-form"),
  username: document.getElementById("username"),
  password: document.getElementById("password"),
  passwordToggle: document.getElementById("password-toggle"),
  demoFill: document.getElementById("demo-fill"),
  loginMessage: document.getElementById("login-message"),
  logoutButton: document.getElementById("logout-button"),
  installButton: document.getElementById("install-button"),
  themeButton: document.getElementById("theme-button"),
  clockGrid: document.getElementById("clock-grid"),
  searchInput: document.getElementById("search-input"),
  continentFilter: document.getElementById("continent-filter"),
  timeFormat: document.getElementById("time-format"),
  sortOrder: document.getElementById("sort-order"),
  favouritesOnly: document.getElementById("favourites-only"),
  resultCount: document.getElementById("result-count"),
  networkStatus: document.getElementById("network-status"),
  emptyState: document.getElementById("empty-state"),
  clearFilters: document.getElementById("clear-filters"),
  deviceTime: document.getElementById("device-time"),
  deviceDate: document.getElementById("device-date"),
  utcTime: document.getElementById("utc-time"),
  utcDate: document.getElementById("utc-date"),
  locationTotal: document.getElementById("location-total"),
  countryTotal: document.getElementById("country-total"),
  continentTotal: document.getElementById("continent-total"),
  favouriteTotal: document.getElementById("favourite-total"),
  compareA: document.getElementById("compare-a"),
  compareB: document.getElementById("compare-b"),
  compareResult: document.getElementById("compare-result")
};

let deferredInstallPrompt = null;
let currentLocations = [];
let visibleLimit = 6;
let inMemorySession = false;
let inMemoryFavourites = [];

function getStorage(type) {
  try {
    const storage = type === "session" ? window.sessionStorage : window.localStorage;
    const testKey = "__chronosphere_test__";
    storage.setItem(testKey, "1");
    storage.removeItem(testKey);
    return storage;
  } catch {
    return null;
  }
}

const sessionStore = getStorage("session");
const localStore = getStorage("local");

function safeGet(store, key, fallback = null) {
  if (!store) return fallback;
  try {
    const value = store.getItem(key);
    return value === null ? fallback : value;
  } catch {
    return fallback;
  }
}

function safeSet(store, key, value) {
  if (!store) return false;
  try {
    store.setItem(key, value);
    return true;
  } catch {
    return false;
  }
}

function safeRemove(store, key) {
  if (!store) return;
  try {
    store.removeItem(key);
  } catch {
    // Storage may be unavailable for file:// pages or privacy-restricted browsers.
  }
}

function loadFavourites() {
  const storedValue = safeGet(localStore, FAVOURITES_KEY, "[]");
  try {
    const parsed = JSON.parse(storedValue);
    if (Array.isArray(parsed)) return new Set(parsed);
  } catch {
    // Use the in-memory fallback below.
  }
  return new Set(inMemoryFavourites);
}

let favourites = loadFavourites();
const formatterCache = new Map();
const zoneValidity = new Map();

function saveFavourites() {
  inMemoryFavourites = [...favourites];
  safeSet(localStore, FAVOURITES_KEY, JSON.stringify(inMemoryFavourites));
}

// Destination photographs are bundled locally; changing a place needs no network.
const destinationUI = Object.fromEntries([
  'select','image','country','flag','heading','region','zone','time','date','caption','credit',
  'day-state','difference','offset','hour-hand','minute-hand','second-hand','save','announcement','photo-error'
].map(name => [name, document.getElementById(`destination-${name}`)]));
let activeDestination = WORLD_LOCATIONS.find(location => location.timezone === safeGet(localStore, 'chronosphere-destination')) || WORLD_LOCATIONS[0];
const orderedDestinations = [...WORLD_LOCATIONS].sort((a,b) => a.country.localeCompare(b.country) || a.city.localeCompare(b.city));
let lastRhythmHour = -1;

function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, character => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[character]));
}
function destinationPhoto(location) { return PHOTO_CATALOG[location.city]; }
function setPhoto(image, location, thumbnail = false) {
  const photo = destinationPhoto(location);
  const source = thumbnail ? photo.thumbnail : photo.src;
  if (image.getAttribute('src') === source) return;
  image.classList.remove('photo-failed');
  image.alt = photo.alt;
  image.style.objectPosition = photo.position || '50% 35%';
  image.src = source;
}
function updateDestinationSelection() {
  const saved = favourites.has(locationKey(activeDestination));
  destinationUI.save.textContent = saved ? '★ Saved place' : '☆ Save place';
  destinationUI.save.setAttribute('aria-pressed', String(saved));
  destinationUI.save.setAttribute('aria-label', `${saved ? 'Remove' : 'Add'} ${activeDestination.city} ${saved ? 'from' : 'to'} favourites`);
  document.querySelectorAll('.clock-card').forEach(card => {
    const selected = card.dataset.timezone === activeDestination.timezone;
    card.classList.toggle('is-selected', selected);
    card.querySelector('.place-photo-button')?.setAttribute('aria-pressed', String(selected));
  });
  document.querySelectorAll('.quick-destination').forEach(button => {
    button.setAttribute('aria-pressed', String(button.dataset.timezone === activeDestination.timezone));
  });
}
function selectDestination(timezone, {scroll = false, announce = true} = {}) {
  const location = WORLD_LOCATIONS.find(item => item.timezone === timezone);
  if (!location) return;
  activeDestination = location;
  safeSet(localStore, 'chronosphere-destination', timezone);
  const photo = destinationPhoto(location);
  destinationUI.select.value = timezone;
  destinationUI.country.textContent = location.country;
  destinationUI.flag.replaceChildren();
  const flag = document.createElement("img");
  flag.src = `assets/flags/${location.code.toLowerCase()}.svg`;flag.alt = "";flag.width = 24;flag.height = 18;
  destinationUI.flag.appendChild(flag);
  destinationUI.heading.textContent = location.city;
  destinationUI.region.textContent = `${location.continent} · LIVE LOCAL TIME`;
  destinationUI.zone.textContent = timezone.replaceAll('_', ' ');
  destinationUI.caption.textContent = photo.caption;
  destinationUI.credit.href = photo.credit;
  if (destinationUI.image.getAttribute('src') !== photo.src) destinationUI['photo-error'].hidden = true;
  setPhoto(destinationUI.image, location);
  document.getElementById('rhythm-city').textContent = location.city;
  lastRhythmHour = -1;
  updateDestinationValues();
  updateDestinationSelection();
  if (announce) destinationUI.announcement.textContent = `${location.city}, ${location.country} selected. Local time ${formatTime(timezone, false)}.`;
  if (scroll) {
    const hero = document.getElementById('destination-hero');
    hero.focus({preventScroll:true});
    document.getElementById('top').scrollIntoView({behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth', block:'start'});
  }
}
function updateDestinationValues() {
  const zone = activeDestination.timezone;
  destinationUI.time.textContent = formatTime(zone);
  destinationUI.date.textContent = formatDate(zone, true);
  const dayState = getDayState(zone);
  destinationUI['day-state'].textContent = `${dayState.icon} ${dayState.label}`;
  const localZone = Intl.DateTimeFormat().resolvedOptions().timeZone;
  const difference = getOffsetMinutes(zone) - getOffsetMinutes(localZone);
  const hours = Math.floor(Math.abs(difference)/60), minutes = Math.abs(difference)%60;
  destinationUI.difference.textContent = difference === 0 ? 'Same time as you' : `${hours ? `${hours}h` : ''}${minutes ? ` ${minutes}m` : ''} ${difference > 0 ? 'ahead' : 'behind'}`.trim();
  destinationUI.offset.textContent = getOffsetLabel(zone);
  const parts = getDateParts(zone), hands = getHands(zone);
  destinationUI['hour-hand'].style.transform = `translateX(-50%) rotate(${hands.hour}deg)`;
  destinationUI['minute-hand'].style.transform = `translateX(-50%) rotate(${hands.minute}deg)`;
  destinationUI['second-hand'].style.transform = `translateX(-50%) rotate(${Number(parts.second)*6}deg)`;
  const hour = Number(parts.hour);
  if (hour !== lastRhythmHour) {
    document.querySelectorAll('.rhythm-bar').forEach((bar,index) => bar.classList.toggle('current',index === hour));
    document.getElementById('rhythm-description').textContent = `${String(hour).padStart(2,'0')}:00 hour · ${dayState.label.toLowerCase()}`;
    lastRhythmHour = hour;
  }
}
function updateComparisonPhotos() {
  setPhoto(document.getElementById('compare-image-a'), selectedLocation(elements.compareA), true);
  setPhoto(document.getElementById('compare-image-b'), selectedLocation(elements.compareB), true);
}
function initialiseDestinations() {
  let group;
  for (const location of orderedDestinations) {
    if (!group || group.label !== location.country) {
      group = document.createElement('optgroup');group.label = location.country;destinationUI.select.appendChild(group);
    }
    const option = document.createElement('option');
    option.value = location.timezone;option.textContent = `${location.city} · ${location.timezone.replaceAll('_',' ')}`;group.appendChild(option);
  }
  for (const city of ['Athens','London','New York','Tokyo','Sydney']) {
    const location = WORLD_LOCATIONS.find(item => item.city === city);
    const button = document.createElement('button');button.type = 'button';button.className = 'quick-destination';button.textContent = city;button.dataset.timezone = location.timezone;
    button.addEventListener('click', () => selectDestination(location.timezone));
    document.querySelector('.quick-destinations').appendChild(button);
  }
  for (let hour = 0; hour < 24; hour++) {
    const bar = document.createElement('span');bar.className = `rhythm-bar ${hour>=9&&hour<17 ? 'working' : ''} ${hour<6||hour>=22 ? 'night' : ''}`;
    document.getElementById('rhythm-bars').appendChild(bar);
  }
  destinationUI.select.addEventListener('change', () => selectDestination(destinationUI.select.value));
  for (const [id,step] of [['destination-prev',-1],['destination-next',1]]) {
    document.getElementById(id).addEventListener('click', () => {
      const index = orderedDestinations.findIndex(location => location.timezone === activeDestination.timezone);
      selectDestination(orderedDestinations[(index+step+orderedDestinations.length)%orderedDestinations.length].timezone);
    });
  }
  destinationUI.save.addEventListener('click', () => toggleFavourite(locationKey(activeDestination), false));
  destinationUI.image.addEventListener('error', () => {destinationUI.image.classList.add('photo-failed');destinationUI['photo-error'].hidden = false;});
  destinationUI.image.addEventListener('load', () => {destinationUI.image.classList.remove('photo-failed');destinationUI['photo-error'].hidden = true;});
  for (const id of ['compare-image-a','compare-image-b']) document.getElementById(id).addEventListener('error', event => event.target.classList.add('photo-failed'));
  document.getElementById('destination-compare').addEventListener('click', () => {
    elements.compareA.value = activeDestination.timezone;
    if (elements.compareB.value === elements.compareA.value) elements.compareB.value = activeDestination.timezone === 'Europe/Athens' ? 'America/New_York' : 'Europe/Athens';
    updateComparator();updateComparisonPhotos();
    elements.compareB.focus({preventScroll:true});
    document.getElementById('comparison').scrollIntoView({behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth'});
  });
  for (const select of [elements.compareA,elements.compareB]) select.addEventListener('change', () => {updateComparisonPhotos();selectDestination(select.value);});
  selectDestination(activeDestination.timezone, {announce:false});
  updateComparisonPhotos();
}

function locationKey(location) {
  return `${location.country}|${location.city}|${location.timezone}`;
}

function isValidTimeZone(timeZone) {
  if (zoneValidity.has(timeZone)) return zoneValidity.get(timeZone);
  try {
    new Intl.DateTimeFormat("en", { timeZone }).format();
    zoneValidity.set(timeZone, true);
    return true;
  } catch {
    return false;
  }
}

function safeFormatter(locale, options, timeZone) {
  const cacheKey = JSON.stringify([locale, options, timeZone]);
  if (formatterCache.has(cacheKey)) return formatterCache.get(cacheKey);
  const finalOptions = timeZone && isValidTimeZone(timeZone)
    ? { ...options, timeZone }
    : options;

  try {
    const formatter = new Intl.DateTimeFormat(locale, finalOptions);
    formatterCache.set(cacheKey, formatter);
    return formatter;
  } catch {
    return new Intl.DateTimeFormat("en-GB", options);
  }
}

function getDateParts(timeZone, date = new Date()) {
  const parts = safeFormatter("en-GB", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hourCycle: "h23",
    year: "numeric",
    month: "2-digit",
    day: "2-digit"
  }, timeZone).formatToParts(date);

  return Object.fromEntries(parts.map(part => [part.type, part.value]));
}

function getTimeValue(timeZone) {
  const parts = getDateParts(timeZone);
  return Number(parts.hour || 0) * 3600 + Number(parts.minute || 0) * 60 + Number(parts.second || 0);
}

function getMinutesInZone(timeZone) {
  const parts = getDateParts(timeZone);
  return Number(parts.hour || 0) * 60 + Number(parts.minute || 0);
}

function getOffsetMinutes(timeZone, date = new Date()) {
  try {
    const parts = safeFormatter("en-US", {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hourCycle: "h23"
    }, timeZone).formatToParts(date);

    const values = Object.fromEntries(parts.map(part => [part.type, part.value]));
    const asUTC = Date.UTC(
      Number(values.year),
      Number(values.month) - 1,
      Number(values.day),
      Number(values.hour),
      Number(values.minute),
      Number(values.second)
    );
    return Math.round((asUTC - date.getTime()) / 60000);
  } catch {
    return 0;
  }
}

function getOffsetLabel(timeZone) {
  try {
    const value = new Intl.DateTimeFormat("en", {
      timeZone,
      timeZoneName: "shortOffset"
    }).formatToParts(new Date()).find(part => part.type === "timeZoneName")?.value;
    return value ? value.replace("GMT", "UTC") : timeZone;
  } catch {
    const offsetMinutes = getOffsetMinutes(timeZone);
    const sign = offsetMinutes >= 0 ? "+" : "−";
    const absolute = Math.abs(offsetMinutes);
    const hours = String(Math.floor(absolute / 60)).padStart(2, "0");
    const minutes = String(absolute % 60).padStart(2, "0");
    return `UTC${sign}${hours}:${minutes}`;
  }
}

function formatTime(timeZone, includeSeconds = true) {
  return safeFormatter("en-GB", {
    hour: "2-digit",
    minute: "2-digit",
    ...(includeSeconds ? { second: "2-digit" } : {}),
    hour12: elements.timeFormat?.value === "12"
  }, timeZone).format(new Date());
}

function formatDate(timeZone, long = false) {
  return safeFormatter("en-GB", long ? {
    weekday: "long",
    day: "2-digit",
    month: "long",
    year: "numeric"
  } : {
    weekday: "short",
    day: "2-digit",
    month: "short",
    year: "numeric"
  }, timeZone).format(new Date());
}

function getDayState(timeZone) {
  const hour = Number(getDateParts(timeZone).hour || 0);
  if (hour >= 6 && hour < 12) return { label: "Morning", icon: "☀" };
  if (hour >= 12 && hour < 18) return { label: "Afternoon", icon: "◐" };
  if (hour >= 18 && hour < 22) return { label: "Evening", icon: "◒" };
  return { label: "Night", icon: "☾" };
}

function formatDifference(minutes) {
  if (minutes === 0) return "Same time as Athens";
  const sign = minutes > 0 ? "+" : "−";
  const absolute = Math.abs(minutes);
  const hours = Math.floor(absolute / 60);
  const remainingMinutes = absolute % 60;
  const value = remainingMinutes ? `${hours}h ${remainingMinutes}m` : `${hours}h`;
  return `${sign}${value} vs Athens`;
}

function getAthensDifference(timeZone) {
  return getOffsetMinutes(timeZone) - getOffsetMinutes(HOME_TIMEZONE);
}

function getHands(timeZone) {
  const parts = getDateParts(timeZone);
  const hour = Number(parts.hour || 0) % 12;
  const minute = Number(parts.minute || 0);
  return {
    hour: hour * 30 + minute * 0.5,
    minute: minute * 6
  };
}

function getFilteredLocations() {
  const searchTerm = elements.searchInput.value.trim().toLocaleLowerCase();
  const selectedContinent = elements.continentFilter.value;

  const filtered = WORLD_LOCATIONS.filter(location => {
    const key = locationKey(location);
    const matchesSearch =
      location.country.toLocaleLowerCase().includes(searchTerm) ||
      location.city.toLocaleLowerCase().includes(searchTerm) ||
      location.timezone.toLocaleLowerCase().includes(searchTerm);
    const matchesContinent = selectedContinent === "All" || location.continent === selectedContinent;
    const matchesFavourite = !elements.favouritesOnly.checked || favourites.has(key);
    return matchesSearch && matchesContinent && matchesFavourite;
  });

  return filtered.sort((a, b) => {
    if (elements.sortOrder.value === "time") {
      return getTimeValue(a.timezone) - getTimeValue(b.timezone);
    }

    if (elements.sortOrder.value === "continent") {
      return a.continent.localeCompare(b.continent) || a.country.localeCompare(b.country);
    }

    if (elements.sortOrder.value === "favourites") {
      const favouriteDifference = Number(favourites.has(locationKey(b))) - Number(favourites.has(locationKey(a)));
      return favouriteDifference || a.country.localeCompare(b.country) || a.city.localeCompare(b.city);
    }

    return a.country.localeCompare(b.country) || a.city.localeCompare(b.city);
  });
}

function buildCard(location, index) {
  const key = locationKey(location);
  const favourite = favourites.has(key);
  const dayState = getDayState(location.timezone);
  const hands = getHands(location.timezone);
  const article = document.createElement("article");
  article.className = `clock-card ${dayState.label === "Night" ? "is-night" : ""}`;
  article.dataset.timezone = location.timezone;
  article.dataset.key = key;

  const photo = destinationPhoto(location);
  article.innerHTML = `
    <button class="place-photo-button" type="button" aria-label="Explore ${escapeHTML(location.city)}, ${escapeHTML(location.country)}" aria-pressed="${location.timezone === activeDestination.timezone}">
      <img src="${photo.thumbnail}" style="object-position:${photo.position || '50% 35%'}" alt="${escapeHTML(photo.alt)}" width="600" height="360" loading="lazy" decoding="async">
      <span class="place-photo-label">Explore place <span aria-hidden="true">↗</span></span>
    </button>
    <div class="card-topline">
      <span class="flag"><img src="assets/flags/${location.code.toLowerCase()}.svg" alt="${location.country} flag" width="24" height="18"></span>
      <div class="card-actions">
        <span class="continent">${location.continent}</span>
        <button class="favourite-button ${favourite ? "active" : ""}" type="button" aria-label="${favourite ? "Remove" : "Add"} ${location.city} ${favourite ? "from" : "to"} favourites" title="${favourite ? "Remove from favourites" : "Add to favourites"}">${favourite ? "★" : "☆"}</button>
      </div>
    </div>
    <div class="location-row">
      <div>
        <h3 class="location-name">${location.city}</h3>
        <p class="country-name">${location.country}</p>
      </div>
      <div class="mini-clock" aria-hidden="true">
        <span class="clock-hand hour-hand" style="transform: translateX(-50%) rotate(${hands.hour}deg)"></span>
        <span class="clock-hand minute-hand" style="transform: translateX(-50%) rotate(${hands.minute}deg)"></span>
      </div>
    </div>
    <p class="time" id="time-${index}">${formatTime(location.timezone)}</p>
    <p class="date" id="date-${index}">${formatDate(location.timezone)}</p>
    <div class="card-bottom">
      <div class="card-bottom-left">
        <span class="day-state">${dayState.icon} ${dayState.label}</span>
        <span class="offset-pill">${getOffsetLabel(location.timezone)}</span>
      </div>
      <span class="time-difference">${formatDifference(getAthensDifference(location.timezone))}</span>
    </div>
  `;

  article.classList.toggle('is-selected', location.timezone === activeDestination.timezone);
  article.querySelector('.place-photo-button').addEventListener('click', () => selectDestination(location.timezone, {scroll:true}));
  article.querySelector('.place-photo-button img').addEventListener('error', event => event.target.classList.add('photo-failed'));
  const favouriteButton = article.querySelector(".favourite-button");
  favouriteButton.addEventListener("click", () => toggleFavourite(key));
  return article;
}

function renderClocks(resetLimit = true) {
  if (resetLimit) visibleLimit = 6;
  const filteredLocations = getFilteredLocations();
  currentLocations = filteredLocations.slice(0, visibleLimit);
  document.getElementById("load-more").hidden = filteredLocations.length <= visibleLimit;
  const fragment = document.createDocumentFragment();

  currentLocations.forEach((location, index) => {
    fragment.appendChild(buildCard(location, index));
  });

  elements.clockGrid.replaceChildren(fragment);

  document.getElementById("nav-world").classList.toggle("active", !elements.favouritesOnly.checked);
  document.getElementById("nav-favourites").classList.toggle("active", elements.favouritesOnly.checked);
  document.getElementById("clocks-title").textContent = elements.favouritesOnly.checked ? "Your favourite places" : "Explore the world";
  elements.resultCount.textContent = `${currentLocations.length} of ${filteredLocations.length} places`;
  elements.emptyState.hidden = currentLocations.length !== 0;
  updateMetrics();
}

function updateClockValues() {
  const now = new Date();

  elements.deviceTime.textContent = safeFormatter("en-GB", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: elements.timeFormat.value === "12"
  }).format(now);
  elements.deviceDate.textContent = safeFormatter("en-GB", {
    weekday: "long",
    day: "2-digit",
    month: "long",
    year: "numeric"
  }).format(now);
  elements.utcTime.textContent = formatTime("UTC");
  elements.utcDate.textContent = formatDate("UTC", true);

  const cards = elements.clockGrid.querySelectorAll(".clock-card");
  cards.forEach((card, index) => {
    const location = currentLocations[index];
    if (!location) return;

    const timeElement = card.querySelector(".time");
    const dateElement = card.querySelector(".date");
    const dayElement = card.querySelector(".day-state");
    const hourHand = card.querySelector(".hour-hand");
    const minuteHand = card.querySelector(".minute-hand");
    const dayState = getDayState(location.timezone);
    const hands = getHands(location.timezone);

    if (timeElement) timeElement.textContent = formatTime(location.timezone);
    if (dateElement) dateElement.textContent = formatDate(location.timezone);
    if (dayElement) dayElement.textContent = `${dayState.icon} ${dayState.label}`;
    if (hourHand) hourHand.style.transform = `translateX(-50%) rotate(${hands.hour}deg)`;
    if (minuteHand) minuteHand.style.transform = `translateX(-50%) rotate(${hands.minute}deg)`;
    card.classList.toggle("is-night", dayState.label === "Night");
  });

  updateComparator();
  updateDestinationValues();
}

function updateMetrics() {
  elements.locationTotal.textContent = WORLD_LOCATIONS.length;
  elements.countryTotal.textContent = new Set(WORLD_LOCATIONS.map(item => item.country)).size;
  elements.continentTotal.textContent = new Set(WORLD_LOCATIONS.map(item => item.continent)).size;
  elements.favouriteTotal.textContent = favourites.size;
}

function toggleFavourite(key, restoreFocus = true) {
  if (favourites.has(key)) {
    favourites.delete(key);
  } else {
    favourites.add(key);
  }
  saveFavourites();
  renderClocks(false);
  const restoredCard = [...elements.clockGrid.children].find(card => card.dataset.key === key);
  if (restoreFocus) {
    const focusTarget = restoredCard?.querySelector('.favourite-button') || elements.clockGrid.querySelector('.favourite-button') || elements.clearFilters;
    focusTarget.focus({preventScroll:true});
  }
  destinationUI.announcement.textContent = `${WORLD_LOCATIONS.find(location => locationKey(location) === key)?.city || 'Place'} ${favourites.has(key) ? 'saved to' : 'removed from'} favourites.`;
  updateComparator();
  updateDestinationSelection();
}

function populateContinents() {
  const continents = [...new Set(WORLD_LOCATIONS.map(location => location.continent))].sort();
  continents.forEach(continent => {
    const option = document.createElement("option");
    option.value = continent;
    option.textContent = continent;
    elements.continentFilter.appendChild(option);
  });
}

function populateComparator() {
  const sortedLocations = [...WORLD_LOCATIONS].sort((a, b) =>
    a.country.localeCompare(b.country) || a.city.localeCompare(b.city)
  );

  [elements.compareA, elements.compareB].forEach(select => {
    sortedLocations.forEach(location => {
      const option = document.createElement("option");
      option.value = location.timezone;
      option.textContent = `${location.city}, ${location.country}`;
      option.dataset.city = location.city;
      option.dataset.country = location.country;
      select.appendChild(option);
    });
  });

  elements.compareA.value = "Europe/Athens";
  elements.compareB.value = "America/New_York";
}

function selectedLocation(select) {
  const timezone = select.value;
  return WORLD_LOCATIONS.find(item => item.timezone === timezone) || WORLD_LOCATIONS[0];
}

function updateComparator() {
  const first = selectedLocation(elements.compareA);
  const second = selectedLocation(elements.compareB);
  const difference = getOffsetMinutes(second.timezone) - getOffsetMinutes(first.timezone);
  const absolute = Math.abs(difference);
  const hours = Math.floor(absolute / 60);
  const minutes = absolute % 60;
  const differenceText = difference === 0
    ? "Same local time"
    : `${second.city} is ${hours}h${minutes ? ` ${minutes}m` : ""} ${difference > 0 ? "ahead of" : "behind"} ${first.city}`;

  const comparisonMarkup = `
    <strong>${differenceText}</strong>
    <span>${formatTime(first.timezone, false)} ↔ ${formatTime(second.timezone, false)}</span>
    <small>${first.city} / ${second.city}</small>
  `;
  if (elements.compareResult.innerHTML !== comparisonMarkup) elements.compareResult.innerHTML = comparisonMarkup;
}

function showDashboard() {
  inMemorySession = true;
  elements.loginView.hidden = true;
  elements.dashboardView.hidden = false;
  document.body.classList.add("authenticated");
  safeSet(sessionStore, AUTH_KEY, "true");
  renderClocks();
  updateClockValues();
  window.scrollTo({ top: 0, behavior: "instant" });
}

function showLogin() {
  inMemorySession = false;
  safeRemove(sessionStore, AUTH_KEY);
  elements.dashboardView.hidden = true;
  elements.loginView.hidden = false;
  document.body.classList.remove("authenticated");
  elements.loginForm.reset();
  elements.password.type = "password";
  elements.passwordToggle.textContent = "Show";
  elements.passwordToggle.setAttribute("aria-label", "Show password");
  elements.loginMessage.textContent = "";
  window.setTimeout(() => elements.username.focus(), 0);
}

function updateNetworkStatus() {
  const online = navigator.onLine;
  elements.networkStatus.textContent = online ? "Online" : "Offline ready";
  elements.networkStatus.className = `status-badge ${online ? "online" : "offline"}`;
}

function clearFilters() {
  elements.searchInput.value = "";
  elements.continentFilter.value = "All";
  elements.favouritesOnly.checked = false;
  elements.sortOrder.value = "country";
  renderClocks();
}

function applyTheme(theme) {
  const selectedTheme = theme === "light" ? "light" : "dark";
  document.documentElement.dataset.theme = selectedTheme;
  elements.themeButton.textContent = selectedTheme === "dark" ? "☼" : "☾";
  elements.themeButton.title = selectedTheme === "dark" ? "Use light theme" : "Use dark theme";
  document.querySelector('meta[name="theme-color"]')?.setAttribute("content", selectedTheme === "dark" ? "#171d1b" : "#f6f7f3");
  safeSet(localStore, THEME_KEY, selectedTheme);
}

function initialiseTheme() {
  const stored = safeGet(localStore, THEME_KEY, null);
  if (stored) {
    applyTheme(stored);
    return;
  }
  applyTheme("light");
}

elements.loginForm.addEventListener("submit", event => {
  event.preventDefault();
  const username = elements.username.value.trim();
  const password = elements.password.value;

  if (username === LOGIN_USERNAME && password === LOGIN_PASSWORD) {
    elements.loginMessage.textContent = "";
    showDashboard();
    return;
  }

  elements.loginMessage.textContent = "Incorrect credentials. Use joker and joker1234.";
  elements.loginPanel.classList.remove("shake");
  void elements.loginPanel.offsetWidth;
  elements.loginPanel.classList.add("shake");
  elements.password.select();
});

elements.demoFill.addEventListener("click", () => {
  showDashboard();
});

elements.passwordToggle.addEventListener("click", () => {
  const showing = elements.password.type === "text";
  elements.password.type = showing ? "password" : "text";
  elements.passwordToggle.textContent = showing ? "Show" : "Hide";
  elements.passwordToggle.setAttribute("aria-label", showing ? "Show password" : "Hide password");
});

elements.logoutButton.addEventListener("click", showLogin);

elements.themeButton.addEventListener("click", () => {
  const nextTheme = document.documentElement.dataset.theme === "dark" ? "light" : "dark";
  applyTheme(nextTheme);
});

[elements.searchInput, elements.continentFilter, elements.timeFormat, elements.sortOrder, elements.favouritesOnly].forEach(control => {
  control.addEventListener("input", () => {renderClocks(); updateClockValues();});
});

elements.timeFormat.addEventListener("change", () => safeSet(localStore, "chronosphere-format", elements.timeFormat.value));
elements.compareA.addEventListener("change", updateComparator);
elements.compareB.addEventListener("change", updateComparator);
elements.clearFilters.addEventListener("click", clearFilters);
window.addEventListener("online", updateNetworkStatus);
window.addEventListener("offline", updateNetworkStatus);

window.addEventListener("beforeinstallprompt", event => {
  event.preventDefault();
  deferredInstallPrompt = event;
  elements.installButton.hidden = false;
});

elements.installButton.addEventListener("click", async () => {
  if (!deferredInstallPrompt) return;
  deferredInstallPrompt.prompt();
  await deferredInstallPrompt.userChoice;
  deferredInstallPrompt = null;
  elements.installButton.hidden = true;
});

window.addEventListener("appinstalled", () => {
  elements.installButton.hidden = true;
  deferredInstallPrompt = null;
});

if ("serviceWorker" in navigator && ["http:", "https:"].includes(window.location.protocol)) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("./sw.js").catch(error => {
      console.error("Service worker registration failed:", error);
    });
  });
}

function initialise() {
  initialiseTheme();
  elements.timeFormat.value = safeGet(localStore, "chronosphere-format", "24") === "12" ? "12" : "24";
  populateContinents();
  populateComparator();
  initialiseDestinations();
  updateNetworkStatus();
  updateMetrics();
  updateComparator();

  const storedAuthentication = safeGet(sessionStore, AUTH_KEY, "false") === "true";
  if (storedAuthentication || inMemorySession) {
    showDashboard();
  } else {
    showLogin();
  }

  window.setInterval(() => { if (!elements.dashboardView.hidden && !document.hidden) updateClockValues(); }, 1000);
}

document.getElementById("load-more").addEventListener("click", () => {
  const previousCount = currentLocations.length;
  visibleLimit += 12;
  renderClocks(false);
  elements.clockGrid.children[previousCount]?.querySelector(".favourite-button").focus({ preventScroll: true });
});
document.getElementById("swap-cities").addEventListener("click", () => {
  [elements.compareA.value, elements.compareB.value] = [elements.compareB.value, elements.compareA.value];
  updateComparator();
  updateComparisonPhotos();
  selectDestination(elements.compareA.value);
});
for (const [id, onlySaved] of [["nav-world", false], ["nav-favourites", true]]) {
  document.getElementById(id).addEventListener("click", () => {
    clearFilters();
    elements.favouritesOnly.checked = onlySaved;
    renderClocks();
    document.getElementById("clocks-title").scrollIntoView({ behavior: "smooth", block: "start" });
  });
}
document.addEventListener("keydown", event => {
  if (event.key === "/" && !elements.dashboardView.hidden && !["INPUT", "SELECT", "TEXTAREA"].includes(document.activeElement.tagName)) {
    event.preventDefault();
    elements.searchInput.focus();
  }
});
initialise();
